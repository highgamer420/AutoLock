-- server/server.lua
-- =================================================================================
--      SCRIPT CREDIT
-- =================================================================================
--      This script was created by CES.
-- =================================================================================
-- print('-------------------------------------------------')
-- print('^2[CES] Ride Share has started successfully.^0')
-- print('^2Thanks for using this resource!^0')
-- print('^2Join the discord for support https://discord.gg/sNANv4dJad!^0')
-- print('-------------------------------------------------')

-- ===== STYLISH VERSION CHECK =====

-- Paste the raw GitHub URL for this script's version file here
local versionUrl = "https://raw.githubusercontent.com/highgamer420/CES-Version-Check/refs/heads/main/F-AutoLock.txt"
-- Your Discord link or website
local discordLink = "https://discord.gg/sNANv4dJad"

-- This is the function that prints our cool banner
local function printBanner(currentVersion, latestVersion)
    local resourceName = GetCurrentResourceName()
    local isUpToDate = (currentVersion == latestVersion)

    -- Set colors based on update status
    -- ^5 = Magenta, ^2 = Green, ^3 = Yellow, ^7 = White
    local latestVersionColor = isUpToDate and "^2" or "^3"
    local updateMessage = isUpToDate and "You are on the latest version!" or "An update is available! Get it from GitHub https://github.com/highgamer420/AutoLock " -- is it Keymaster or GitHub
    local updateMessageColor = isUpToDate and "^2" or "^3"

   -- ASCII Art for "CES"
    local banner = {
        "|-----------------------------------------------------------------------|",
        "|                ^5Crazy Eyes Studio^7                                  |",
        "|-----------------------------------------------------------------------|",
        string.format("|         SCRIPT: %-48s  |", resourceName),
        "|-----------------------------------------------------------------------|",
        string.format("|      INSTALLED: %-12s LATEST STABLE: %s%-15s^7 |", currentVersion, latestVersionColor, latestVersion),
        "|-----------------------------------------------------------------------|",
        string.format("|      %s%-60s^7 |", updateMessageColor, updateMessage),
        string.format("|      Updates, Support, Feedback: %-30s |", discordLink),
        "|-----------------------------------------------------------------------|"
    }
    -- Print each line of the banner
    for _, line in ipairs(banner) do
        print(line)
    end
end

-- This code runs when the resource starts
Citizen.CreateThread(function()
    -- Wait 10 seconds for everything to load before checking
    Citizen.Wait(10000)

    PerformHttpRequest(versionUrl, function(errorCode, resultText, resultHeaders)
        if errorCode == 200 then
            -- We successfully fetched the latest version number
            local latestVersion = resultText:match("^%s*(.-)%s*$") -- Trim whitespace
            local currentVersion = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)

            -- Print the banner with the version info we found
            printBanner(currentVersion, latestVersion)
        else
            -- If we couldn't fetch the version, print a simple error
            print(string.format("[CES] ^1Could not check for updates for %s.^7", GetCurrentResourceName()))
        end
    end)
end)

-- ===== END VERSION CHECK =====
-- ===== END VERSION CHECK =====
-- ===== END VERSION CHECK =====