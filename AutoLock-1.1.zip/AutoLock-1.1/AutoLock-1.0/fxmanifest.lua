fx_version 'bodacious'
game 'gta5'

lua54 'yes'

author 'Crazy Eyes Stuido'
description 'AutoLock'
version '1.1.0'

client_script "client.lua"

server_scripts {
    'server/server.lua'
}
